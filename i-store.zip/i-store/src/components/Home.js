import React from "react";

function Home(props) {
  return (
    <div class="bkgrnd">
      <h1>i Store</h1>

      <div class="container">
        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcSw2PYcQkUzAFqiya4I-Ax66c5PwOkyGmU_sGvyZZzi96N8ibgkwBCQ3cojsh9Pgs8y28Vgvzs69kLhJgd0GMe7C2wIqrc03d6IFcFVGkHevGbxpCabVSxyFg4&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 15 pro</span>
            <p>Price: $1000.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>

        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRByhafFtGdHJEujdJscRXSoQR-X3AHMOw3-xLUuUZtn8OgJy9NZnEP5OjAkpDqGM5JrVvSWYMXWasrbmL8b5tJVWJ26O7kioRLpUJeWZB-nt6W8coUUjsUQDM&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 15 plus</span>
            <p>Price: $950.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>

        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcSA_0JK0m9fvQnhm2A1visXwa1kvCefgkgLAvRIixBgqTPnadcWrzJMOemNvq0w-Jt1KW-ywjBgZOGDyvABk2_1goS4gJs7ehr8UiBnEFyDcsWjuV_25Vp8YA&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 14 pro</span>
            <p>Price: $900.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>

        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcRpmOg_z9A4JOK0DOO0ceNa2qxi0gSJLaTZyh4TGjnZm0Tfe30ZWUoTkf1DCkeX6N9dQCcunG6bO6EIUge2GBVqfs1xjSt9GZBOXIn8yDyy20v1GBrrbVlnvw&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 14 </span>
            <p>Price: $850.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>

        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcRQuzjYbOUEK5lnPgbnpj2YHXfC5bQXrkkCLW5Nx9AzPrQqB8s-oJqy09ta2IFOm3A4u7mGqcxHZwuDNtAsjNFSP-WGQJnoGn3ByIMynjt30VUUKNzwE84ogQ&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 13 pro</span>
            <p>Price: $750.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>
      </div>

      <div class="container2">
        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcSbzGNlfJS7YljAq9ZNtDAlYBE00BI2K55bF2uemcqElYTtm_cW3vtfRwLodk5Rkpq8W73r7Zlo5oB_1Oc2UD-LG8aBr-EGYRgHlxG7T4rbmTFOyAuR95VjYA&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 11</span>
            <p>Price: $500.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>

        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQj8zEdh7EW-qQRvIOVlA8r7iWPObQ6BQGtA_V4P9kJ1dtHiEnFqmDqSnXT56nQF6N8ZT9J5hLTjdVdyRt4Egpi4FHcPPQDIgf66S1w4AI&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 12 pro</span>
            <p>Price: $550.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>

        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQgGXlXxNcuqTOIcVaprXwdAL5ZtkM8hJlr2GPRoCUf7jnY4CCz0tOFhvnjsH8HikxrThoL7iPcrF7tPkKvCpqS_vz-0dTgsS0V95jChkaiQv6LoPC2vZp1iQ&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone X</span>
            <p>Price: $450.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>

        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRaWL7mrqIbV4MHL5HpAplXaZ0lWnSxzoRJkP2fO1RrcbGLMJ8PP-2DpgzGJWiihJ3J_eaVarstExeF8Sk89q2joqADTaUeA9b-Ya9q7IIj1g_enQ-JcT42&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 8 Plus </span>
            <p>Price: $400.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>

        <div className="cart-wrapper">
          <div className="img-wrapper item">
            <img src="https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQUeN8uZ7DUaDimXKAkGxFAVsE_6rrQ7gBjN9WS1jKwmTirlX7dtFQt6zjmRPKaHQ84x6rzpLHUnNl8aSMmWl_Kr-dYijf5vMoZ6YcEw6nQzgEmWhngsCk-K0U&usqp=CAE" />
          </div>
          <div className="text-wrapper item">
            <span>i Phone 8</span>
            <p>Price: $35'0.00</p>
          </div>

          <div className="btn-wrapper item">
            <button
              onClick={() => {
                props.addToCartHandler({ pice: 1000, name: "i phone 11" });
              }}
            >
              Add To Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Home;
