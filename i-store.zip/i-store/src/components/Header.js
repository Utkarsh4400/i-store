import React from "react";
function Header(props) {
  console.warn(props.data);
  return (
    <div>
      <div className="add-to-cart">
        <span className="cart-count">{props.data.length}</span>
        <img src="https://png.pngtree.com/png-vector/20190320/ourmid/pngtree-vector-shopping-cart-icon-png-image_850694.jpg" />
      </div>
    </div>
  );
}

export default Header;
